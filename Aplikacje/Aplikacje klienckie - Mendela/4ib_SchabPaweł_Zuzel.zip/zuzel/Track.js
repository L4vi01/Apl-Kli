export class Track {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.createGrassPattern();

        // Tworzymy bufor (offscreenCanvas) do sprawdzania kolizji
        this.offscreenCanvas = document.createElement('canvas');
        this.offscreenCanvas.width = canvas.width;
        this.offscreenCanvas.height = canvas.height;
        this.offscreenCtx = this.offscreenCanvas.getContext('2d');

        this.drawTrack();
    }

    createGrassPattern() {
        this.grassColor = '#008080';
    }

    drawTrack() {
        const ctx = this.ctx;
        const offscreenCtx = this.offscreenCtx;

        // Czyścimy oba canvasy
        ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        offscreenCtx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Rysujemy tło – trawę
        ctx.fillStyle = this.grassColor;
        ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        offscreenCtx.fillStyle = this.grassColor;
        offscreenCtx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Parametry toru
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;
        const trackWidth = this.canvas.width * 0.75;
        const trackHeight = this.canvas.height * 0.7;
        const trackThickness = 100;
        const outerRadius = trackHeight / 2;
        const innerRadius = outerRadius - trackThickness;

        this.outerRadius = outerRadius;
        this.trackThickness = trackThickness;

        // Rysujemy biały fragment toru
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(centerX - trackWidth / 4, centerY, outerRadius, Math.PI / 2, -Math.PI / 2);
        ctx.arc(centerX + trackWidth / 4, centerY, outerRadius, -Math.PI / 2, Math.PI / 2);
        ctx.closePath();
        ctx.fill();

        offscreenCtx.fillStyle = '#ffffff';
        offscreenCtx.beginPath();
        offscreenCtx.arc(centerX - trackWidth / 4, centerY, outerRadius, Math.PI / 2, -Math.PI / 2);
        offscreenCtx.arc(centerX + trackWidth / 4, centerY, outerRadius, -Math.PI / 2, Math.PI / 2);
        offscreenCtx.closePath();
        offscreenCtx.fill();

        // Rysujemy wewnętrzny fragment toru (trawę)
        ctx.fillStyle = this.grassColor;
        ctx.beginPath();
        ctx.arc(centerX - trackWidth / 4, centerY, innerRadius, Math.PI / 2, -Math.PI / 2);
        ctx.arc(centerX + trackWidth / 4, centerY, innerRadius, -Math.PI / 2, Math.PI / 2);
        ctx.closePath();
        ctx.fill();

        offscreenCtx.fillStyle = this.grassColor;
        offscreenCtx.beginPath();
        offscreenCtx.arc(centerX - trackWidth / 4, centerY, innerRadius, Math.PI / 2, -Math.PI / 2);
        offscreenCtx.arc(centerX + trackWidth / 4, centerY, innerRadius, -Math.PI / 2, Math.PI / 2);
        offscreenCtx.closePath();
        offscreenCtx.fill();

        // Rysujemy offscreenCanvas na głównym canvasie
        ctx.drawImage(this.offscreenCanvas, 0, 0);

        // Rysujemy linię mety
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 4;
        const finishLineX = centerX;
        const finishLineStartY = centerY + (outerRadius - trackThickness / 2) * 0.8;
        const finishLineEndY = centerY + (outerRadius + trackThickness / 2) * 0.8;
        ctx.beginPath();
        ctx.moveTo(finishLineX, finishLineStartY);
        ctx.lineTo(finishLineX, finishLineEndY);
        ctx.stroke();

        offscreenCtx.strokeStyle = '#000000';
        offscreenCtx.lineWidth = 4;
        offscreenCtx.beginPath();
        offscreenCtx.moveTo(finishLineX, finishLineStartY);
        offscreenCtx.lineTo(finishLineX, finishLineEndY);
        offscreenCtx.stroke();

        // Wzór startowy (szachownica)
        const stripeSize = 10;
        const patternCanvas = document.createElement('canvas');
        patternCanvas.width = stripeSize * 2;
        patternCanvas.height = stripeSize * 2;
        const pctx = patternCanvas.getContext('2d');

        pctx.fillStyle = '#FFFFFF';
        pctx.fillRect(0, 0, stripeSize, stripeSize);
        pctx.fillRect(stripeSize, stripeSize, stripeSize, stripeSize);
        pctx.fillStyle = '#000000';
        pctx.fillRect(stripeSize, 0, stripeSize, stripeSize);
        pctx.fillRect(0, stripeSize, stripeSize, stripeSize);

        const chessPatternMain = ctx.createPattern(patternCanvas, 'repeat');
        const chessPatternOff = offscreenCtx.createPattern(patternCanvas, 'repeat');

        const playerStartY = centerY + (outerRadius - trackThickness / 2) * 0.8 + 40;
        const patternHeight = 80;
        const patternTopY = playerStartY - patternHeight / 2;
        const patternX = centerX - stripeSize / 2;

        ctx.fillStyle = chessPatternMain;
        ctx.fillRect(patternX, patternTopY, stripeSize, patternHeight);

        offscreenCtx.fillStyle = chessPatternOff;
        offscreenCtx.fillRect(patternX, patternTopY, stripeSize, patternHeight);

        const borderColor = '#CCCCCC';
        const borderWidth = 1;
        ctx.strokeStyle = borderColor;
        ctx.lineWidth = borderWidth;
        ctx.strokeRect(patternX, patternTopY, stripeSize, patternHeight);

        offscreenCtx.strokeStyle = borderColor;
        offscreenCtx.lineWidth = borderWidth;
        offscreenCtx.strokeRect(patternX, patternTopY, stripeSize, patternHeight);

        // Strzałka poniżej obszaru startowego
        const arrowBaseY = patternTopY + patternHeight;
        const arrowTipY = arrowBaseY + 10;
        const arrowBaseWidth = 20;

        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.moveTo(centerX - arrowBaseWidth / 2, arrowBaseY);
        ctx.lineTo(centerX + arrowBaseWidth / 2, arrowBaseY);
        ctx.lineTo(centerX, arrowTipY);
        ctx.closePath();
        ctx.fill();
    }

    isCollision(x, y) {
        const pixel = this.offscreenCtx.getImageData(x, y, 1, 1).data;
        const isTurquoise = pixel[0] === 0 && pixel[1] === 128 && pixel[2] === 128;
        return isTurquoise;
    }

    getStartPosition() {
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;
        const trackHeight = this.canvas.height * 0.7;
        const trackThickness = 100;
        const outerRadius = trackHeight / 2;
        return {
            x: centerX,
            y: centerY + (outerRadius - trackThickness / 2) * 0.8,
            angle: 0
        };
    }
}