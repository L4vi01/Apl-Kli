export class Player {
    constructor(canvas, startPosition, track, config) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.track = track;
        const { x, y, angle } = startPosition;
        Object.assign(this, { x, y, angle });

        this.speed = 1.5;
        this.turnSpeed = 0.02;
        this.keys = { left: false };
        this.config = config;
        const { color, image: imageSrc } = config;
        Object.assign(this, { color, imageSrc });

        this.gameOver = false;
        this.lapsCompleted = 0;
        this.lastFinishLineCross = 0;
        this.lastY = y;

        this.image = new Image();
        this.image.src = this.imageSrc;

        this.trail = [];
        this.trailFadeTime = 100;
    }

    update() {
        if (this.gameOver) return;

        const [newX, newY] = [
            this.x + Math.cos(this.angle) * this.speed,
            this.y + Math.sin(this.angle) * this.speed
        ];

        this.lastY = this.y;

        if (!this.track.isCollision(newX, newY)) {
            [this.x, this.y] = [newX, newY];

            this.trail.push({ x: this.x, y: this.y, life: this.trailFadeTime });
            this.trail = this.trail.filter(point => point.life > 0);
            this.trail.forEach(point => point.life--);
        } else {
            this.gameOver = true;
        }

        if (!this.gameOver && this.keys.left) {
            this.angle -= this.turnSpeed;
        }
    }

    draw() {
        this.ctx.save();
        this.trail.forEach(point => {
            const alpha = point.life / this.trailFadeTime;
            this.ctx.fillStyle = `rgba(0, 0, 0, ${alpha})`;
            this.ctx.beginPath();
            this.ctx.arc(point.x, point.y, 2, 0, Math.PI * 2);
            this.ctx.fill();
        });
        this.ctx.restore();

        if (this.image.complete) {
            this.ctx.save();
            this.ctx.translate(this.x, this.y);
            this.ctx.rotate(this.angle);
            const [width, height] = [60, 30];
            this.ctx.drawImage(this.image, -width / 2, -height / 2, width, height);
            this.ctx.restore();
        } else {
            this.ctx.fillStyle = this.color;
            this.ctx.beginPath();
            this.ctx.arc(this.x, this.y, 10, 0, Math.PI * 2);
            this.ctx.fill();
        }
    }
}