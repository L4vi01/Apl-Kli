import { Game } from './Game.js';

// Inicjalizacja gry po załadowaniu strony
window.addEventListener('load', () => {
    new Game();
});
