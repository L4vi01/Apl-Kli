import { Track } from './Track.js';
import { Player } from './Player.js';

export class Game {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.setupCanvas();
        this.track = new Track(this.canvas);
        this.players = this.createPlayers();
        this.lapCount = 5;
        this.remainingLaps = this.lapCount;
        this.setupKeyListeners();
        this.gameLoop();
    }

    setupCanvas() {
        Object.assign(this.canvas, { width: 1000, height: 700 });
    }

    setupKeyListeners() {
        const handleKey = (isKeyDown) => (e) => {
            this.players.forEach(player => {
                if (e.key === player.config.keys.left) {
                    player.keys.left = isKeyDown;
                }
            });
        };

        window.addEventListener('keydown', handleKey(true));
        window.addEventListener('keyup', handleKey(false));
    }

    createPlayers() {
        const startPosition = this.track.getStartPosition();
        const playerConfigs = [
            { keys: { left: 'a' }, color: 'red', image: 'moto-red.png' },
            { keys: { left: 'j' }, color: 'blue', image: 'moto-blue.png' },
            { keys: { left: 'v' }, color: 'orange', image: 'moto-orange.png' },
            { keys: { left: 'q' }, color: 'green', image: 'moto-main.png' }
        ];

        const spacing = 25;
        return playerConfigs.map((config, index) => {
            const position = {
                ...startPosition,
                y: startPosition.y + index * spacing
            };
            return new Player(this.canvas, position, this.track, config);
        });
    }

    update() {
        this.players.forEach(player => {
            if (!player.gameOver) {
                player.update();
                if (this.playerCrossedFinishLine(player)) {
                    player.lapsCompleted++;
                    if (player.lapsCompleted >= this.lapCount) {
                        this.endGame(player);
                    }
                }
            }
        });

        this.remainingLaps = this.lapCount - Math.max(...this.players.map(p => p.lapsCompleted));
    }

    playerCrossedFinishLine(player) {
        const { width: canvasWidth, height: canvasHeight } = this.canvas;
        const { outerRadius, trackThickness } = this.track;

        const finishLineX = canvasWidth / 2;
        const finishLineY = {
            start: canvasHeight / 2 + (outerRadius - trackThickness / 2) * 0.8,
            end: canvasHeight / 2 + (outerRadius + trackThickness / 2) * 0.8
        };

        const currentTime = Date.now();
        const isMovingDown = player.y > player.lastY;

        const crossedFinishLine = (
            player.x > finishLineX - 5 &&
            player.x < finishLineX + 5 &&
            player.y > finishLineY.start &&
            player.y < finishLineY.end &&
            isMovingDown &&
            currentTime - player.lastFinishLineCross > 2000
        );

        if (crossedFinishLine) {
            player.lastFinishLineCross = currentTime;
        }

        return crossedFinishLine;
    }

    endGame(winner) {
        alert(`Gracz ${winner.color} wygrywa!`);
        this.players.forEach(player => player.gameOver = true);
    }

    draw() {
        this.ctx.drawImage(this.track.offscreenCanvas, 0, 0);
        this.players.forEach(player => player.draw());

        const textConfig = {
            font: '36px Arial',
            fillStyle: 'black',
            textAlign: 'center'
        };

        Object.assign(this.ctx, textConfig);
        this.ctx.fillText(`Pozostałe okrążenia: ${this.remainingLaps}`, this.canvas.width / 2, 50);
    }

    gameLoop() {
        if (this.players.every(player => player.gameOver)) {
            alert('Wszyscy gracze odpadli!');
            return;
        }
        this.update();
        this.draw();
        requestAnimationFrame(() => this.gameLoop());
    }
}