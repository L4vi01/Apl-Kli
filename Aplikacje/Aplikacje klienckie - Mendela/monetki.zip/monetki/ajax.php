<?php
include("hidden.php");
$mysqli = new mysqli($host, $user, $passwd, $dbname);
$mysqli->query("SET NAMES utf8");

if (isset($_POST['acc'])) {
    switch ($_POST['acc']) {
        case 'get':
            $sql = "SELECT monety.id, monety.nazwa, kraje.nazwa AS kraj, kraje.flaga, materialy.nazwa AS material
                    FROM monety
                    JOIN kraje ON monety.kraj_id = kraje.id
                    JOIN materialy ON monety.material_id = materialy.id";
            $result = $mysqli->query($sql);
            echo json_encode($result->fetch_all(MYSQLI_ASSOC));
            break;

        case 'add':
            $nazwa = rawurldecode($_POST['nazwa']);
            $kraj_id = intval($_POST['kraj_id']);
            $material_id = intval($_POST['material_id']);
            $stmt = $mysqli->prepare("INSERT INTO monety (nazwa, kraj_id, material_id) VALUES (?, ?, ?)");
            $stmt->bind_param("sii", $nazwa, $kraj_id, $material_id);
            $stmt->execute();
            break;

        case 'delete':
            $id = intval($_POST['id']);
            $stmt = $mysqli->prepare("DELETE FROM monety WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            break;

        case 'edit':
            $id = intval($_POST['id']);
            $nazwa = rawurldecode($_POST['nazwa']);
            $kraj_id = intval($_POST['kraj_id']);
            $material_id = intval($_POST['material_id']);
            $stmt = $mysqli->prepare("UPDATE monety SET nazwa=?, kraj_id=?, material_id=? WHERE id=?");
            $stmt->bind_param("siii", $nazwa, $kraj_id, $material_id, $id);
            $stmt->execute();
            break;
    }
}
?>