<?php
$dbname = "monetki_db";
$host = "localhost";
$user = "root";
$passwd = "";
?>