-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2025 at 09:03 PM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monetki_db`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kraje`
--

CREATE TABLE `kraje` (
  `id` int(11) NOT NULL,
  `nazwa` varchar(100) NOT NULL,
  `flaga` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kraje`
--

INSERT INTO `kraje` (`id`, `nazwa`, `flaga`) VALUES
(1, 'Albania', 'flags/Albania.jpg'),
(2, 'Algieria', 'flags/Algieria.jpg'),
(3, 'Australia', 'flags/Australia.jpg'),
(4, 'Barbados', 'flags/Barbados.jpg'),
(5, 'Belgia', 'flags/Belgia.jpg'),
(6, 'Belize', 'flags/Belize.jpg'),
(7, 'Bermudy', 'flags/Bermudy.jpg'),
(8, 'Bhutan', 'flags/Bhutan.jpg'),
(9, 'Boliwia', 'flags/Boliwia.jpg');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `materialy`
--

CREATE TABLE `materialy` (
  `id` int(11) NOT NULL,
  `nazwa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `materialy`
--

INSERT INTO `materialy` (`id`, `nazwa`) VALUES
(1, 'Złoto'),
(2, 'Srebro'),
(3, 'Miedź');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `monety`
--

CREATE TABLE `monety` (
  `id` int(11) NOT NULL,
  `nazwa` varchar(100) NOT NULL,
  `nr_kat` varchar(50) NOT NULL,
  `rok` int(11) NOT NULL,
  `kraj_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `monety`
--

INSERT INTO `monety` (`id`, `nazwa`, `nr_kat`, `rok`, `kraj_id`, `material_id`) VALUES
(30, 'asgag', '', 0, 3, 1),
(32, 'lek', '', 1996, 2, 2),
(33, 'groschen', '', 1947, 3, 3),
(36, 'cent', '', 1978, 6, 3),
(38, 'ngultrum', '', 2222, 8, 2),
(39, 'cent', '', 1979, 9, 3),
(41, 'Złoty', '', 0, 6, 3);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `kraje`
--
ALTER TABLE `kraje`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `materialy`
--
ALTER TABLE `materialy`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `monety`
--
ALTER TABLE `monety`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kraj_id` (`kraj_id`),
  ADD KEY `material_id` (`material_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kraje`
--
ALTER TABLE `kraje`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `materialy`
--
ALTER TABLE `materialy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `monety`
--
ALTER TABLE `monety`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `monety`
--
ALTER TABLE `monety`
  ADD CONSTRAINT `monety_ibfk_1` FOREIGN KEY (`kraj_id`) REFERENCES `kraje` (`id`),
  ADD CONSTRAINT `monety_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `materialy` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
