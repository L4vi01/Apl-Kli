document.addEventListener("DOMContentLoaded", get);

function get() {
    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "ajax.php");
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let json = JSON.parse(this.responseText);
            let out = document.getElementById("out");
            out.innerHTML = "";
            json.forEach(moneta => {
                let div = document.createElement("tr");
                div.setAttribute("data-id", moneta.id);
                div.innerHTML = `
                    <td><img src="${moneta.flaga}" onclick="edit(${moneta.id}, '${moneta.nazwa}', ${moneta.kraj_id}, ${moneta.material_id})"></td>
                    <td>${moneta.nazwa}</td>
                    <td>${moneta.material}</td>
                    <td>${moneta.rok}</td>
                    <td class="action-btns">
                        <button onclick="remove(${moneta.id})">Usuń</button>
                    </td>
                `;
                out.appendChild(div);
            });
        }
    };
    xhttp.send("acc=get");
}

function send() {
    let nazwa = encodeURIComponent(document.getElementById("nazwa").value);
    let kraj_id = document.getElementById("kraj").value;
    let material_id = document.getElementById("material").value;

    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "ajax.php");
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) get();
    };
    xhttp.send(`acc=add&nazwa=${nazwa}&kraj_id=${kraj_id}&material_id=${material_id}`);
}

function remove(id) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "ajax.php");
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) get();
    };
    xhttp.send(`acc=delete&id=${id}`);
}

function edit(id, nazwa, kraj_id, material_id) {
    let div = document.querySelector(`[data-id="${id}"]`);
    if (!div) return;

    div.innerHTML = `
        <td><img src="${kraj_id}.jpg" alt="Flaga"></td>
        <td><input type="text" id="edit-nazwa-${id}" value="${nazwa}"></td>
        <td>
            <select id="edit-material-${id}">
                <option value="1" ${material_id == 1 ? 'selected' : ''}>Złoto</option>
                <option value="2" ${material_id == 2 ? 'selected' : ''}>Srebro</option>
                <option value="3" ${material_id == 3 ? 'selected' : ''}>Miedź</option>
            </select>
        </td>
        <td><button onclick="save(${id})">✔</button></td>
        <td><button onclick="get()">✖</button></td>
    `;
}

function save(id) {
    let nazwa = encodeURIComponent(document.getElementById(`edit-nazwa-${id}`).value);
    let material_id = document.getElementById(`edit-material-${id}`).value;
    let kraj_id = id; // Załóżmy, że id jest przekazywane jako ID kraju

    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "ajax.php");
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) get();
    };
    xhttp.send(`acc=edit&id=${id}&nazwa=${nazwa}&material_id=${material_id}&kraj_id=${kraj_id}`);
}
