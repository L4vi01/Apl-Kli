<?php
// Przykładowy skrypt PHP
$title = "Moja strona";

function sayHello($name) {
    return "Witaj " . $name . "!";
}

$greeting = sayHello("Użytkowniku");
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $title; ?></title>
</head>
<body>
    <h1><?php echo $greeting; ?></h1>
</body>
</html>