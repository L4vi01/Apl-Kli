let currentFilter = 'none';
let editedImage;

window.onload = function () {
    editedImage = document.getElementById('editedImage');
    updateImageDimensions();
};

function updateImageDimensions() {
    const dimensions = document.getElementById('imageDimensions');
    if (dimensions && editedImage) {
        dimensions.textContent = `${editedImage.naturalWidth} x ${editedImage.naturalHeight} px`;
    }
}

function toggleFilters() {
    const filterControls = document.querySelector('.filter-controls');
    filterControls.classList.toggle('show');
}

function applyFilter(filter) {
    currentFilter = currentFilter === filter ? 'none' : filter;
    switch (currentFilter) {
        case 'grayscale':
            editedImage.style.filter = 'grayscale(100%)';
            break;
        case 'sepia':
            editedImage.style.filter = 'sepia(100%)';
            break;
        case 'invert':
            editedImage.style.filter = 'invert(100%)';
            break;
        case 'contrast':
            editedImage.style.filter = 'contrast(150%)';
            break;
        default:
            editedImage.style.filter = 'none';
            break;
    }
}

function resetFilters() {
    currentFilter = 'none';
    editedImage.style.filter = 'none';
}

function saveChanges() {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = editedImage.naturalWidth;
    canvas.height = editedImage.naturalHeight;
    ctx.filter = editedImage.style.filter;
    ctx.drawImage(editedImage, 0, 0);

    const imageData = canvas.toDataURL();
    const fileName = editedImage.alt;

    fetch('/save-image', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            fileName: fileName,
            imageData: imageData
        })
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Zmiany zostały zapisane!');
            } else {
                alert('Wystąpił błąd podczas zapisywania zmian.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Wystąpił błąd podczas zapisywania zmian.');
        });
}

function renameFile() {
    const dialog = document.getElementById('renameFileDialog');
    dialog.showModal();
}

function closeRenameDialog() {
    const dialog = document.getElementById('renameFileDialog');
    dialog.close();
}

function confirmRename() {
    document.querySelector('#renameFileDialog form').submit();
}