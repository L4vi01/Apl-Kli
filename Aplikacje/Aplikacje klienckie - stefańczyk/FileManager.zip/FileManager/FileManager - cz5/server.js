const express = require("express");
const path = require("path");
const fs = require("fs");
const formidable = require("formidable");
const hbs = require("express-handlebars");

const app = express();
const PORT = 3000;
const BASE_DIR = path.join(__dirname, "upload");
const CONFIG_FILE = path.join(__dirname, "config.json");

// Inicjalizacja pliku konfiguracyjnego
if (!fs.existsSync(CONFIG_FILE)) {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify({
        fontSize: 16,
        backgroundColor: '#ffffff',
        textColor: '#f5f5f5'
    }));
}

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("static"));
app.use("/upload", express.static("upload"));

app.set("views", path.join(__dirname, "views"));
app.engine("hbs", hbs({
    defaultLayout: "main.hbs",
    helpers: {
        eq: function (v1, v2) {
            return v1 === v2;
        },
        isDirectory: function (name, options) {
            const fullPath = path.join(BASE_DIR, options.data.root.root, name);
            if (fs.existsSync(fullPath)) {
                return fs.statSync(fullPath).isDirectory();
            } else {
                return false;
            }
        },
        getFileIcon: function (name) {
            const extension = path.extname(name).toLowerCase();
            switch (extension) {
                case ".png":
                    return "iconpng.png";
                case ".txt":
                    return "icontxt.png";
                case ".jpg":
                    return "iconjpg.png";
                case ".html":
                    return "iconhtml.png";
                case ".css":
                    return "iconcss.png";
                case ".js":
                    return "iconjs.png";
                case ".json":
                    return "iconjson.png";
                case ".xml":
                    return "iconxml.png";
                case ".zip":
                    return "iconzip.png";
                case ".gif":
                    return "icongif.png";
                case ".pdf":
                    return "iconpdf.png";
                case ".java":
                    return "iconjava.png";
                case ".php":
                    return "iconphp.png";
                case ".py":
                    return "iconpy.png";
                case ".sql":
                    return "iconsql.png";
                default:
                    return "iconcancel.png";
            }
        }
    }
}));
app.set("view engine", "hbs");

// Utwórz folder upload, jeśli nie istnieje
if (!fs.existsSync(BASE_DIR)) {
    fs.mkdirSync(BASE_DIR);
}

// Obsługa głównego trasy `/`
app.get("/", (req, res) => {
    res.redirect("/filemanager");
});

// Wyświetlanie plików i katalogów
app.get("/filemanager", (req, res) => {
    const root = req.query.root || "";
    const dirPath = path.join(BASE_DIR, root);
    fs.readdir(dirPath, (err, files) => {
        if (err) {
            console.error(err);
            res.status(500).send("Błąd serwera");
        } else {
            const pathArray = root.split("/").filter(Boolean).map((dir, index, arr) => {
                return { name: dir, path: arr.slice(0, index + 1).join("/") };
            });
            const context = { files, root, pathArray };
            res.render("filemanager.hbs", context);
        }
    });
});

// Utworzenie nowego katalogu
app.post("/create-directory", (req, res) => {
    const root = req.body.root || "";
    const dirName = req.body.dirName;
    const dirPath = path.join(BASE_DIR, root, dirName);
    fs.mkdir(dirPath, { recursive: true }, (err) => {
        if (err) {
            console.error(err);
            res.status(500).send("Błąd tworzenia katalogu");
        } else {
            res.redirect(`/filemanager?root=${root}`);
        }
    });
});

// Utworzenie nowego pliku tekstowego
app.post("/create-file", (req, res) => {
    const root = req.body.root || "";
    const fileName = req.body.fileName;
    const extension = req.body.extension;
    const filePath = path.join(BASE_DIR, root, `${fileName}.${extension}`);

    let defaultContent = "";
    switch (extension) {
        case "py":
            defaultContent = `# Przykładowy skrypt Python

class Example:
    def __init__(self):
        self.message = "Hello, World!"
    
    def get_message(self):
        return self.message

def main():
    example = Example()
    print(example.get_message())

if __name__ == "__main__":
    main()`;
            break;
        case "java":
            defaultContent = `public class ${fileName} {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}`;
            break;
        case "css":
            defaultContent = `/* Podstawowe style */
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}`;
            break;
        case "php":
            defaultContent = `<?php
// Przykładowy skrypt PHP
$title = "Moja strona";

function sayHello($name) {
    return "Witaj " . $name . "!";
}

$greeting = sayHello("Użytkowniku");
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $title; ?></title>
</head>
<body>
    <h1><?php echo $greeting; ?></h1>
</body>
</html>`;
            break;
        case "html":
            defaultContent = `<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nowa strona</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Witaj na mojej stronie!</h1>
        <p>To jest przykładowa strona HTML.</p>
    </div>
</body>
</html>`;
            break;
    }

    fs.writeFile(filePath, defaultContent, (err) => {
        if (err) {
            console.error(err);
            res.status(500).send("Błąd tworzenia pliku");
        } else {
            res.redirect(`/filemanager?root=${root}`);
        }
    });
});

// Usunięcie katalogu
app.get("/delete-directory", (req, res) => {
    const root = req.query.root || "";
    const dirName = req.query.dirName;
    const dirPath = path.join(BASE_DIR, root, dirName);
    fs.rmdir(dirPath, { recursive: true }, (err) => {
        if (err) {
            console.error(err);
            res.status(500).send("Błąd usuwania katalogu");
        } else {
            res.redirect(`/filemanager?root=${root}`);
        }
    });
});

// Usunięcie pliku
app.get("/delete-file", (req, res) => {
    const root = req.query.root || "";
    const fileName = req.query.fileName;
    const filePath = path.join(BASE_DIR, root, fileName);
    fs.unlink(filePath, (err) => {
        if (err) {
            console.error(err);
            res.status(500).send("Błąd usuwania pliku");
        } else {
            res.redirect(`/filemanager?root=${root}`);
        }
    });
});

// Upload plików
app.post("/upload-file", (req, res) => {
    let root = "";
    const form = new formidable.IncomingForm({
        keepExtensions: true,
        multiples: true,
    });

    form.parse(req, (err, fields, files) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Błąd przesyłania pliku");
        }

        root = fields.root || "";

        const uploadedFiles = Array.isArray(files.filetoupload) ? files.filetoupload : [files.filetoupload];

        const tasks = uploadedFiles.map((file) => new Promise((resolve, reject) => {
            console.log('File:', file); // Debugging output
            const oldPath = file.path;
            const originalFilename = file.name;

            if (!originalFilename) {
                console.error('No original filename found.');
                return reject(new Error("Brak oryginalnej nazwy pliku"));
            }

            const newPath = path.join(BASE_DIR, root, originalFilename);

            // Ensure the new path directory exists
            const newDir = path.dirname(newPath);
            if (!fs.existsSync(newDir)) {
                fs.mkdirSync(newDir, { recursive: true });
            }

            fs.copyFile(oldPath, newPath, (err) => {
                if (err) {
                    console.error(err);
                    return reject(new Error("Błąd podczas kopiowania pliku"));
                }

                fs.unlink(oldPath, (err) => {
                    if (err) {
                        console.error(err);
                        return reject(new Error("Błąd podczas usuwania pliku tymczasowego"));
                    }
                    resolve();
                });
            });
        }));

        Promise.all(tasks)
            .then(() => res.redirect(`/filemanager?root=${root}`))
            .catch((error) => {
                console.error(error);
                res.status(500).send(error.message);
            });
    });
});

// Zmiana nazwy katalogu
app.post("/rename-directory", (req, res) => {
    const root = req.body.root || "";
    const oldName = req.body.oldName;
    const newName = req.body.newName;
    const oldPath = path.join(BASE_DIR, root, oldName);
    const newPath = path.join(BASE_DIR, root, newName);

    if (!fs.existsSync(newPath)) {
        fs.rename(oldPath, newPath, (err) => {
            if (err) console.error(err);
            res.redirect(`/filemanager?root=${root.replace(oldName, newName)}`);
        });
    } else {
        res.status(400).send("Nazwa już istnieje");
    }
});

// Wyświetlanie zawartości pliku
app.get("/showfile", (req, res) => {
    const fileName = req.query.name;
    const root = req.query.root || "";
    if (!fileName) {
        return res.status(400).send("Nie podano nazwy pliku");
    }

    const filePath = path.join(BASE_DIR, root, fileName);
    if (!fs.existsSync(filePath)) {
        return res.status(404).send("Plik nie istnieje");
    }

    const fileExtension = path.extname(fileName).toLowerCase();
    const isImage = ['.jpg', '.jpeg', '.png', '.gif'].includes(fileExtension);

    if (isImage) {
        res.render("editor_image.hbs", {
            fileName,
            fileNameWithoutExt: path.basename(fileName, fileExtension),
            fileExtension: fileExtension.substring(1)
        });
    } else {
        const fileContent = fs.readFileSync(filePath, 'utf8');
        const fileNameWithoutExt = path.basename(fileName, fileExtension);
        const config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));

        res.render("edytor.hbs", {
            fileName,
            fileNameWithoutExt,
            fileExtension: fileExtension.substring(1),
            fileContent,
            config
        });
    }
});

// Zapisywanie pliku
app.post("/save-file", (req, res) => {
    const { fileName, content } = req.body;
    const filePath = path.join(BASE_DIR, fileName);

    fs.writeFile(filePath, content, 'utf8', (err) => {
        if (err) {
            console.error(err);
            res.status(500).send("Błąd zapisywania pliku");
        } else {
            res.status(200).send("Plik zapisany pomyślnie");
        }
    });
});

// Zmiana nazwy pliku
app.post("/rename-file", (req, res) => {
    const { oldName, newName, extension } = req.body;
    const oldPath = path.join(BASE_DIR, oldName);
    const newPath = path.join(BASE_DIR, `${newName}.${extension}`);

    if (!fs.existsSync(oldPath)) {
        return res.status(404).send("Plik nie istnieje");
    }

    if (fs.existsSync(newPath)) {
        return res.status(400).send("Plik o takiej nazwie już istnieje");
    }

    fs.rename(oldPath, newPath, (err) => {
        if (err) {
            console.error(err);
            res.status(500).send("Błąd zmiany nazwy pliku");
        } else {
            res.redirect(`/showfile?name=${newName}.${extension}`);
        }
    });
});

// Obsługa endpointu /editor
app.get("/editor", (req, res) => {
    const fileName = req.query.name;
    const root = req.query.root || "";
    if (!fileName) {
        return res.status(400).send("Nie podano nazwy pliku");
    }
    res.redirect(`/showfile?name=${fileName}&root=${root}`);
});

// Zapisywanie konfiguracji
app.post("/save-config", (req, res) => {
    const { fontSize, backgroundColor, textColor } = req.body;
    fs.writeFileSync(CONFIG_FILE, JSON.stringify({ fontSize, backgroundColor, textColor }));
    res.status(200).send("Konfiguracja zapisana");
});

// Zapisywanie zmodyfikowanego obrazu
app.post('/save-image', (req, res) => {
    const { fileName, imageData } = req.body;
    const filePath = path.join(BASE_DIR, fileName);

    // Usuń prefix base64
    const base64Data = imageData.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');

    fs.writeFile(filePath, buffer, (err) => {
        if (err) {
            console.error('Error saving image:', err);
            res.json({ success: false, error: err.message });
        } else {
            res.json({ success: true });
        }
    });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
